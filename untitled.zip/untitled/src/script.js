function scopri() {
  // Inserisci il link per "Scoprire"
  window.location.href = 'URL_PER_SCOPRIRE';
}

function leggi() {
  // Inserisci il link per "Leggere"
  window.location.href = 'URL_PER_LEGGERE';
}

function guarda() {
  // Inserisci il link per "Guardare"
  window.location.href = 'URL_PER_GUARDARE';
}

function linkedin() {
  // Inserisci il link per il profilo LinkedIn
  window.location.href = 'URL_LINKEDIN';
}

function instagram() {
  // Inserisci il link per il profilo Instagram
  window.location.href = 'URL_INSTAGRAM';
}

function youtube() {
  // Inserisci il link per il canale YouTube
  window.location.href = 'URL_YOUTUBE';
}
